<?php
/**
 * WordPress Blog Abilities for MCP
 *
 * @wordpress-plugin
 * Plugin Name: Blog Abilities for MCP
 * Description: Registers blog post abilities (create, update, list, delete) for the MCP Adapter.
 * Version: 1.4.0
 * Requires at least: 6.8
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */

add_action( 'wp_abilities_api_categories_init', function () {
	wp_register_ability_category( 'content', [
		'label'       => 'Content',
		'description' => 'Abilities for managing WordPress content.',
	] );
} );

add_action( 'wp_abilities_api_init', function () {

	// Create post
	wp_register_ability( 'blog/create-post', [
		'label'       => 'Create Blog Post',
		'description' => 'Create a new WordPress blog post.',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'title'   => [ 'type' => 'string', 'description' => 'Post title' ],
				'content' => [ 'type' => 'string', 'description' => 'Post content (HTML or plain text)' ],
				'status'  => [
					'type'    => 'string',
					'enum'    => [ 'publish', 'draft', 'pending' ],
					'default' => 'draft',
					'description' => 'Post status',
				],
				'excerpt' => [ 'type' => 'string', 'description' => 'Short excerpt (optional)' ],
				'tags'    => [
					'type'  => 'array',
					'items' => [ 'type' => 'string' ],
					'description' => 'Tag names to attach (optional)',
				],
				'categories' => [
					'type'  => 'array',
					'items' => [ 'type' => 'string' ],
					'description' => 'Category names to attach (optional)',
				],
			],
			'required' => [ 'title', 'content' ],
		],
		'output_schema' => [
			'type'       => 'object',
			'properties' => [
				'id'        => [ 'type' => 'integer' ],
				'title'     => [ 'type' => 'string' ],
				'status'    => [ 'type' => 'string' ],
				'permalink' => [ 'type' => 'string' ],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'publish_posts' );
		},
		'execute_callback' => function ( $input ) {
			$args = [
				'post_title'   => sanitize_text_field( $input['title'] ),
				'post_content' => wp_kses_post( $input['content'] ),
				'post_status'  => $input['status'] ?? 'draft',
				'post_excerpt' => isset( $input['excerpt'] ) ? sanitize_text_field( $input['excerpt'] ) : '',
				'post_author'  => get_current_user_id(),
			];

			$post_id = wp_insert_post( $args, true );
			if ( is_wp_error( $post_id ) ) {
				return new WP_Error( 'create_failed', $post_id->get_error_message() );
			}

			if ( ! empty( $input['tags'] ) ) {
				wp_set_post_tags( $post_id, $input['tags'], false );
			}

			if ( ! empty( $input['categories'] ) ) {
				$cat_ids = array_filter( array_map( function ( $name ) {
					$cat = get_term_by( 'name', $name, 'category' );
					if ( ! $cat ) {
						$result = wp_insert_term( $name, 'category' );
						return is_wp_error( $result ) ? null : $result['term_id'];
					}
					return $cat->term_id;
				}, $input['categories'] ) );
				wp_set_post_categories( $post_id, $cat_ids );
			}

			return [
				'id'        => $post_id,
				'title'     => get_the_title( $post_id ),
				'status'    => get_post_status( $post_id ),
				'permalink' => get_permalink( $post_id ),
			];
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

	// Update post
	wp_register_ability( 'blog/update-post', [
		'label'       => 'Update Blog Post',
		'description' => 'Update title, content, status, excerpt, tags, or categories of an existing post.',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'id'           => [ 'type' => 'integer', 'description' => 'Post ID to update' ],
				'title'        => [ 'type' => 'string', 'description' => 'New title (optional)' ],
				'content'      => [ 'type' => 'string', 'description' => 'New content (optional)' ],
				'status'       => [
					'type' => 'string',
					'enum' => [ 'publish', 'draft', 'pending', 'trash' ],
					'description' => 'New status (optional)',
				],
				'excerpt'      => [ 'type' => 'string', 'description' => 'New excerpt (optional)' ],
				'tags'         => [
					'type'  => 'array',
					'items' => [ 'type' => 'string' ],
					'description' => 'Tag names to set — replaces existing tags (optional)',
				],
				'tag_ids'      => [
					'type'  => 'array',
					'items' => [ 'type' => 'integer' ],
					'description' => 'Tag IDs to set directly — replaces existing tags (optional)',
				],
				'categories'   => [
					'type'  => 'array',
					'items' => [ 'type' => 'string' ],
					'description' => 'Category names to set — replaces existing categories (optional)',
				],
				'category_ids' => [
					'type'  => 'array',
					'items' => [ 'type' => 'integer' ],
					'description' => 'Category IDs to set directly — replaces existing categories (optional)',
				],
			],
			'required' => [ 'id' ],
		],
		'output_schema' => [
			'type'       => 'object',
			'properties' => [
				'id'          => [ 'type' => 'integer' ],
				'title'       => [ 'type' => 'string' ],
				'status'      => [ 'type' => 'string' ],
				'permalink'   => [ 'type' => 'string' ],
				'tags'        => [ 'type' => 'array', 'items' => [ 'type' => 'string' ] ],
				'categories'  => [ 'type' => 'array', 'items' => [ 'type' => 'string' ] ],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'execute_callback' => function ( $input ) {
			$post_id = (int) $input['id'];
			$post    = get_post( $post_id );
			if ( ! $post ) {
				return new WP_Error( 'not_found', 'Post not found.' );
			}

			$args = [ 'ID' => $post_id ];
			if ( isset( $input['title'] ) )   $args['post_title']   = sanitize_text_field( $input['title'] );
			if ( isset( $input['content'] ) ) $args['post_content'] = wp_kses_post( $input['content'] );
			if ( isset( $input['status'] ) )  $args['post_status']  = $input['status'];
			if ( isset( $input['excerpt'] ) ) $args['post_excerpt'] = sanitize_text_field( $input['excerpt'] );

			$updated = wp_update_post( $args, true );
			if ( is_wp_error( $updated ) ) {
				return new WP_Error( 'update_failed', $updated->get_error_message() );
			}

			// Tags by name
			if ( ! empty( $input['tags'] ) ) {
				wp_set_post_tags( $post_id, $input['tags'], false );
			}

			// Tags by ID
			if ( ! empty( $input['tag_ids'] ) ) {
				wp_set_object_terms( $post_id, array_map( 'intval', $input['tag_ids'] ), 'post_tag' );
			}

			// Categories by name
			if ( ! empty( $input['categories'] ) ) {
				$cat_ids = array_filter( array_map( function ( $name ) {
					$cat = get_term_by( 'name', $name, 'category' );
					if ( ! $cat ) {
						$result = wp_insert_term( $name, 'category' );
						return is_wp_error( $result ) ? null : $result['term_id'];
					}
					return $cat->term_id;
				}, $input['categories'] ) );
				wp_set_post_categories( $post_id, array_values( $cat_ids ) );
			}

			// Categories by ID
			if ( ! empty( $input['category_ids'] ) ) {
				wp_set_post_categories( $post_id, array_map( 'intval', $input['category_ids'] ) );
			}

			$tag_terms = wp_get_post_tags( $post_id, [ 'fields' => 'names' ] );
			$cat_terms = wp_get_post_categories( $post_id, [ 'fields' => 'names' ] );

			return [
				'id'         => $post_id,
				'title'      => get_the_title( $post_id ),
				'status'     => get_post_status( $post_id ),
				'permalink'  => get_permalink( $post_id ),
				'tags'       => is_array( $tag_terms ) ? $tag_terms : [],
				'categories' => is_array( $cat_terms ) ? $cat_terms : [],
			];
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

	// List posts
	wp_register_ability( 'blog/list-posts', [
		'label'       => 'List Blog Posts',
		'description' => 'Retrieve a list of blog posts with optional filters.',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'status'       => [
					'type'    => 'string',
					'enum'    => [ 'publish', 'draft', 'pending', 'any' ],
					'default' => 'any',
				],
				'numberposts' => [ 'type' => 'integer', 'default' => 10, 'minimum' => 1, 'maximum' => 100 ],
				'search'       => [ 'type' => 'string', 'description' => 'Keyword search (optional)' ],
			],
		],
		'output_schema' => [
			'type'  => 'array',
			'items' => [
				'type'       => 'object',
				'properties' => [
					'id'        => [ 'type' => 'integer' ],
					'title'     => [ 'type' => 'string' ],
					'status'    => [ 'type' => 'string' ],
					'date'      => [ 'type' => 'string' ],
					'permalink' => [ 'type' => 'string' ],
				],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'execute_callback' => function ( $input ) {
			$args = [
				'post_status'  => $input['status'] ?? 'any',
				'numberposts'  => $input['numberposts'] ?? 10,
				'post_type'    => 'post',
			];
			if ( ! empty( $input['search'] ) ) {
				$args['s'] = sanitize_text_field( $input['search'] );
			}

			$posts = get_posts( $args );
			return array_map( function ( $p ) {
				return [
					'id'        => $p->ID,
					'title'     => $p->post_title,
					'status'    => $p->post_status,
					'date'      => $p->post_date,
					'permalink' => get_permalink( $p->ID ),
				];
			}, $posts );
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

	// Get single post with full content
	wp_register_ability( 'blog/get-post', [
		'label'       => 'Get Blog Post',
		'description' => 'Retrieve full content and metadata of a single post by ID.',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'id' => [ 'type' => 'integer', 'description' => 'Post ID to retrieve' ],
			],
			'required' => [ 'id' ],
		],
		'output_schema' => [
			'type'       => 'object',
			'properties' => [
				'id'          => [ 'type' => 'integer' ],
				'title'       => [ 'type' => 'string' ],
				'content'     => [ 'type' => 'string' ],
				'excerpt'     => [ 'type' => 'string' ],
				'status'      => [ 'type' => 'string' ],
				'date'        => [ 'type' => 'string' ],
				'permalink'   => [ 'type' => 'string' ],
				'tags'        => [ 'type' => 'array', 'items' => [ 'type' => 'string' ] ],
				'tag_ids'     => [ 'type' => 'array', 'items' => [ 'type' => 'integer' ] ],
				'categories'  => [ 'type' => 'array', 'items' => [ 'type' => 'string' ] ],
				'category_ids'=> [ 'type' => 'array', 'items' => [ 'type' => 'integer' ] ],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'execute_callback' => function ( $input ) {
			$post = get_post( (int) $input['id'] );
			if ( ! $post ) {
				return new WP_Error( 'not_found', 'Post not found.' );
			}

			$tag_terms = wp_get_post_tags( $post->ID );
			$cat_terms = get_the_category( $post->ID );

			return [
				'id'           => $post->ID,
				'title'        => $post->post_title,
				'content'      => $post->post_content,
				'excerpt'      => $post->post_excerpt,
				'status'       => $post->post_status,
				'date'         => $post->post_date,
				'permalink'    => get_permalink( $post->ID ),
				'tags'         => array_map( fn( $t ) => $t->name, $tag_terms ),
				'tag_ids'      => array_map( fn( $t ) => $t->term_id, $tag_terms ),
				'categories'   => array_map( fn( $c ) => $c->name, $cat_terms ),
				'category_ids' => array_map( fn( $c ) => $c->term_id, $cat_terms ),
			];
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

	// List tags
	wp_register_ability( 'blog/list-tags', [
		'label'       => 'List Tags',
		'description' => 'Retrieve all post tags with their IDs, names, slugs, and post counts.',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'search' => [ 'type' => 'string', 'description' => 'Filter tags by name (optional)' ],
				'hide_empty' => [ 'type' => 'boolean', 'default' => false, 'description' => 'Exclude tags with no posts (default: false)' ],
			],
		],
		'output_schema' => [
			'type'  => 'array',
			'items' => [
				'type'       => 'object',
				'properties' => [
					'id'    => [ 'type' => 'integer' ],
					'name'  => [ 'type' => 'string' ],
					'slug'  => [ 'type' => 'string' ],
					'count' => [ 'type' => 'integer' ],
				],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'execute_callback' => function ( $input ) {
			$args = [
				'taxonomy'   => 'post_tag',
				'hide_empty' => $input['hide_empty'] ?? false,
				'number'     => 0,
				'orderby'    => 'name',
				'order'      => 'ASC',
			];
			if ( ! empty( $input['search'] ) ) {
				$args['search'] = sanitize_text_field( $input['search'] );
			}
			$tags = get_terms( $args );
			if ( is_wp_error( $tags ) ) {
				return new WP_Error( 'fetch_failed', $tags->get_error_message() );
			}
			return array_map( function ( $t ) {
				return [
					'id'    => $t->term_id,
					'name'  => $t->name,
					'slug'  => $t->slug,
					'count' => $t->count,
				];
			}, $tags );
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

	// List categories
	wp_register_ability( 'blog/list-categories', [
		'label'       => 'List Categories',
		'description' => 'Retrieve all post categories with their IDs, names, slugs, and post counts.',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'search' => [ 'type' => 'string', 'description' => 'Filter categories by name (optional)' ],
				'hide_empty' => [ 'type' => 'boolean', 'default' => false, 'description' => 'Exclude categories with no posts (default: false)' ],
			],
		],
		'output_schema' => [
			'type'  => 'array',
			'items' => [
				'type'       => 'object',
				'properties' => [
					'id'     => [ 'type' => 'integer' ],
					'name'   => [ 'type' => 'string' ],
					'slug'   => [ 'type' => 'string' ],
					'count'  => [ 'type' => 'integer' ],
					'parent' => [ 'type' => 'integer' ],
				],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'execute_callback' => function ( $input ) {
			$args = [
				'taxonomy'   => 'category',
				'hide_empty' => $input['hide_empty'] ?? false,
				'number'     => 0,
				'orderby'    => 'name',
				'order'      => 'ASC',
			];
			if ( ! empty( $input['search'] ) ) {
				$args['search'] = sanitize_text_field( $input['search'] );
			}
			$cats = get_terms( $args );
			if ( is_wp_error( $cats ) ) {
				return new WP_Error( 'fetch_failed', $cats->get_error_message() );
			}
			return array_map( function ( $c ) {
				return [
					'id'     => $c->term_id,
					'name'   => $c->name,
					'slug'   => $c->slug,
					'count'  => $c->count,
					'parent' => $c->parent,
				];
			}, $cats );
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

	// Schedule post
	wp_register_ability( 'blog/schedule-post', [
		'label'       => 'Schedule Post',
		'description' => 'Schedule a post to be published automatically at a future date and time.',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'id'   => [ 'type' => 'integer', 'description' => 'Post ID to schedule' ],
				'date' => [ 'type' => 'string', 'description' => 'Publish date in YYYY-MM-DD HH:MM:SS format (site timezone)' ],
			],
			'required' => [ 'id', 'date' ],
		],
		'output_schema' => [
			'type'       => 'object',
			'properties' => [
				'id'             => [ 'type' => 'integer' ],
				'title'          => [ 'type' => 'string' ],
				'status'         => [ 'type' => 'string' ],
				'scheduled_date' => [ 'type' => 'string' ],
				'permalink'      => [ 'type' => 'string' ],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'execute_callback' => function ( $input ) {
			$post_id = (int) $input['id'];
			$post    = get_post( $post_id );
			if ( ! $post ) {
				return new WP_Error( 'not_found', 'Post not found.' );
			}

			$date = sanitize_text_field( $input['date'] );
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $date ) ) {
				return new WP_Error( 'invalid_date', 'Date must be in YYYY-MM-DD HH:MM:SS format.' );
			}

			$now = current_time( 'mysql' );
			if ( $date <= $now ) {
				return new WP_Error( 'past_date', 'Scheduled date must be in the future.' );
			}

			$updated = wp_update_post( [
				'ID'          => $post_id,
				'post_status' => 'future',
				'post_date'   => $date,
			], true );

			if ( is_wp_error( $updated ) ) {
				return new WP_Error( 'schedule_failed', $updated->get_error_message() );
			}

			return [
				'id'             => $post_id,
				'title'          => get_the_title( $post_id ),
				'status'         => get_post_status( $post_id ),
				'scheduled_date' => $date,
				'permalink'      => get_permalink( $post_id ),
			];
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

	// Create tag
	wp_register_ability( 'blog/create-tag', [
		'label'       => 'Create Tag',
		'description' => 'Create a new post tag.',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'name'        => [ 'type' => 'string', 'description' => 'Tag name' ],
				'slug'        => [ 'type' => 'string', 'description' => 'Tag slug (optional, auto-generated if omitted)' ],
				'description' => [ 'type' => 'string', 'description' => 'Tag description (optional)' ],
			],
			'required' => [ 'name' ],
		],
		'output_schema' => [
			'type'       => 'object',
			'properties' => [
				'id'          => [ 'type' => 'integer' ],
				'name'        => [ 'type' => 'string' ],
				'slug'        => [ 'type' => 'string' ],
				'description' => [ 'type' => 'string' ],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'manage_categories' );
		},
		'execute_callback' => function ( $input ) {
			$args = [];
			if ( ! empty( $input['slug'] ) )        $args['slug']        = sanitize_title( $input['slug'] );
			if ( ! empty( $input['description'] ) ) $args['description'] = sanitize_text_field( $input['description'] );

			$existing = get_term_by( 'name', $input['name'], 'post_tag' );
			if ( $existing ) {
				return new WP_Error( 'tag_exists', "Tag \"{$input['name']}\" already exists with ID {$existing->term_id}." );
			}

			$result = wp_insert_term( sanitize_text_field( $input['name'] ), 'post_tag', $args );
			if ( is_wp_error( $result ) ) {
				return new WP_Error( 'create_failed', $result->get_error_message() );
			}

			$term = get_term( $result['term_id'], 'post_tag' );
			return [
				'id'          => $term->term_id,
				'name'        => $term->name,
				'slug'        => $term->slug,
				'description' => $term->description,
			];
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

	// Duplicate post
	wp_register_ability( 'blog/duplicate-post', [
		'label'       => 'Duplicate Post',
		'description' => 'Duplicate an existing post as a new draft, preserving content, tags, and categories.',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'id'    => [ 'type' => 'integer', 'description' => 'Post ID to duplicate' ],
				'title' => [ 'type' => 'string', 'description' => 'Title for the duplicate (optional, defaults to original title + " (Copy)")' ],
			],
			'required' => [ 'id' ],
		],
		'output_schema' => [
			'type'       => 'object',
			'properties' => [
				'id'        => [ 'type' => 'integer' ],
				'title'     => [ 'type' => 'string' ],
				'status'    => [ 'type' => 'string' ],
				'permalink' => [ 'type' => 'string' ],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'publish_posts' );
		},
		'execute_callback' => function ( $input ) {
			$original = get_post( (int) $input['id'] );
			if ( ! $original ) {
				return new WP_Error( 'not_found', 'Post not found.' );
			}

			$new_title = ! empty( $input['title'] )
				? sanitize_text_field( $input['title'] )
				: $original->post_title . ' (Copy)';

			$new_id = wp_insert_post( [
				'post_title'   => $new_title,
				'post_content' => $original->post_content,
				'post_excerpt' => $original->post_excerpt,
				'post_status'  => 'draft',
				'post_author'  => get_current_user_id(),
				'post_type'    => 'post',
			], true );

			if ( is_wp_error( $new_id ) ) {
				return new WP_Error( 'duplicate_failed', $new_id->get_error_message() );
			}

			// Copy tags and categories
			$tags = wp_get_post_tags( $original->ID, [ 'fields' => 'ids' ] );
			$cats = wp_get_post_categories( $original->ID );
			if ( ! empty( $tags ) ) wp_set_object_terms( $new_id, $tags, 'post_tag' );
			if ( ! empty( $cats ) ) wp_set_post_categories( $new_id, $cats );

			return [
				'id'        => $new_id,
				'title'     => get_the_title( $new_id ),
				'status'    => get_post_status( $new_id ),
				'permalink' => get_permalink( $new_id ),
			];
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

	// List comments
	wp_register_ability( 'blog/list-comments', [
		'label'       => 'List Comments',
		'description' => 'Retrieve comments, optionally filtered by post or status.',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'post_id' => [ 'type' => 'integer', 'description' => 'Filter by post ID (optional)' ],
				'status'  => [
					'type'    => 'string',
					'enum'    => [ 'approve', 'hold', 'spam', 'trash', 'all' ],
					'default' => 'approve',
					'description' => 'Comment status filter (default: approve)',
				],
				'number'  => [ 'type' => 'integer', 'default' => 20, 'minimum' => 1, 'maximum' => 100, 'description' => 'Number of comments to return (default: 20)' ],
			],
		],
		'output_schema' => [
			'type'  => 'array',
			'items' => [
				'type'       => 'object',
				'properties' => [
					'id'      => [ 'type' => 'integer' ],
					'post_id' => [ 'type' => 'integer' ],
					'author'  => [ 'type' => 'string' ],
					'email'   => [ 'type' => 'string' ],
					'date'    => [ 'type' => 'string' ],
					'content' => [ 'type' => 'string' ],
					'status'  => [ 'type' => 'string' ],
				],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'execute_callback' => function ( $input ) {
			$args = [
				'status' => $input['status'] ?? 'approve',
				'number' => $input['number'] ?? 20,
				'type'   => 'comment',
				'orderby'=> 'comment_date',
				'order'  => 'DESC',
			];
			if ( ! empty( $input['post_id'] ) ) {
				$args['post_id'] = (int) $input['post_id'];
			}

			$comments = get_comments( $args );
			return array_map( function ( $c ) {
				return [
					'id'      => (int) $c->comment_ID,
					'post_id' => (int) $c->comment_post_ID,
					'author'  => $c->comment_author,
					'email'   => $c->comment_author_email,
					'date'    => $c->comment_date,
					'content' => wp_strip_all_tags( $c->comment_content ),
					'status'  => $c->comment_approved === '1' ? 'approve' : ( $c->comment_approved === '0' ? 'hold' : $c->comment_approved ),
				];
			}, $comments );
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

	// Delete / trash post
	wp_register_ability( 'blog/delete-post', [
		'label'       => 'Delete Blog Post',
		'description' => 'Move a post to trash (or permanently delete if already trashed).',
		'category'    => 'content',
		'input_schema' => [
			'type'       => 'object',
			'properties' => [
				'id'        => [ 'type' => 'integer', 'description' => 'Post ID to delete' ],
				'force'     => [ 'type' => 'boolean', 'default' => false, 'description' => 'Permanently delete instead of trash' ],
			],
			'required' => [ 'id' ],
		],
		'output_schema' => [
			'type'       => 'object',
			'properties' => [
				'success' => [ 'type' => 'boolean' ],
				'message' => [ 'type' => 'string' ],
			],
		],
		'permission_callback' => function () {
			return current_user_can( 'delete_posts' );
		},
		'execute_callback' => function ( $input ) {
			$result = wp_delete_post( (int) $input['id'], (bool) ( $input['force'] ?? false ) );
			if ( ! $result ) {
				return [ 'success' => false, 'message' => 'Failed to delete post or post not found.' ];
			}
			$action = ( $input['force'] ?? false ) ? 'permanently deleted' : 'moved to trash';
			return [ 'success' => true, 'message' => "Post {$input['id']} {$action}." ];
		},
		'meta' => [ 'mcp' => [ 'public' => true ] ],
	] );

} );
